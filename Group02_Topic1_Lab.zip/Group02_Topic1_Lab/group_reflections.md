# Group Reflections — Topic 1 Lab

**System:** ChatGPT

**Group members:**
- Wan Safiah - A24AI0096
- Nurul Asyiqin - A24AI0080
- Nurul Ain - A24AI0079
- Laila Suhaila - A24AI0110

---

## Part A Reflection — Conversational AI vs Recommendation Systems

The quality dimension that differs most between conversational AI systems and recommendation systems is personalisation. Conversational AI systems such as ChatGPT focus on answering user questions accurately and following instructions, whereas recommendation systems such as YouTube or Spotify focus on suggesting content based on users’ interests and viewing or listening behaviour.

For example, another group observing YouTube or Spotify may find that searching for a particular topic changes the recommended videos or songs on their home feed. This demonstrates personalisation because the recommendations may adapt to the user's activity. In contrast, our Part A observation showed that ChatGPT provided a factual answer about Malaysia’s capital and explained its limitations when answering questions about recent events. This highlights accuracy and transparency as important quality dimensions for conversational AI.

Therefore, personalisation is more central to recommendation systems, while accuracy and instruction-following are more prominent in conversational AI. However, both systems require transparency and fairness to ensure that users receive reliable and appropriate outputs.

---

## Part B Reflection — Where to Concentrate Engineering Effort

In our ChatGPT system map, the language model and the stages that feed into it (conversation context and information sources) attract the most "what could go wrong?" annotations. The model itself carries two failure points: hallucination (F3), where plausible but false details may be trusted (recorded in our observation sheet as a potential risk, not an observed failure), and unclear capability boundaries (F6), where a user expects a completed flight booking. Three more failure points sit directly upstream or downstream of it: ambiguous prompts that lose the user's intent in the context stage (F1), outdated or incomplete knowledge in the information sources (F2), and harmful content passing through the output checks (F4). Only privacy (F5) belongs mainly to the user input. This suggests that the response-generation core, where context, knowledge and the model's output come together, is where most things can fail.

This suggests that engineering effort should be concentrated on this core rather than spread evenly across the system. Context handling, knowledge freshness, hallucination control and output checking all influence whether the final answer is correct and appropriate, so a weakness at any of them reaches the user directly. Because the system map is a conceptual approximation, these components are assumed rather than observed, but our Part A tests support the same priorities: the flight-booking and "Is Python good?" responses showed that interpreting the request and stating what the system can actually do are weak points, while the safety refusal showed that guardrails can work well.

These failure points connect to the quality dimensions from Topic 1. F1, F2 and F3 relate mainly to accuracy, because incorrect or outdated information produces wrong answers. F1 and F6 relate to scope handling and instruction-following, as the system must interpret the request correctly and respond within its real capabilities. F6 also relates to transparency, since users should be told clearly what the system can and cannot do, as ChatGPT did when it explained its limitations on recent events. F4 relates to safety, and F5 matches the Privacy and Security risk recorded in our observation sheet. Therefore, engineering effort should be prioritised on accuracy and scope handling at the model core, supported by transparency about limitations, output safety checks, and the evaluation and monitoring component shown in the map.
